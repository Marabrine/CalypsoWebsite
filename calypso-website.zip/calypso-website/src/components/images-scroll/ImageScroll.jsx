import { useState, useEffect } from "react";
import { ChevronLeft, ChevronRight, Pause, Play } from "lucide-react";

const ImageScroll = () => {
  return <div></div>;
};
export default ImageScroll;
