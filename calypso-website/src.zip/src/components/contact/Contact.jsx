import "./Contact.css";

function Contact() {
  return (
    <div>
      <p>
        <strong>Phone:</strong> +1 438 778 7574
      </p>
      <p>
        <strong>E-mail:</strong> calypsomusicinstruments@hotmail.com
      </p>
    </div>
  );
}
export default Contact;
