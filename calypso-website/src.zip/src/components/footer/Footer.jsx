import "./Footer.css";
function Footer() {
  return (
    <div className="footer-body">
      <footer>kdjfsdgslidfgnilsdufgrpseidugf</footer>
    </div>
  );
}
export default Footer;
